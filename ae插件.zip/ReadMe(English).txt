This article was translated using DeepL. 


The current version of the preset is 1.4.0.

This preset should work fine when the expression engine is JavaScript. If you experience any errors, please change the expression engine to JavaScript. 
※ When used as a legacy ExtendScript, some features may not work and performance may suffer. 

For more information on how to use it, please check the link
https://youtu.be/cvvfA6MmhDo

If you don't know how to install, 
please read 'Howtoinstall.txt'.

- GlyphGlide.ffx: This is the main part of this preset pack.
- GlyphFlow.ffx: Adds a mask to a text layer that creates a flow of letters at PathPoint locations.
- GlyphTrace.ffx: This is an animation tracer that goes into a decorative layer. (This is for advanced users as it is difficult to use).


Thank you for purchasing the preset. 
You are purchasing a license to use the preset, not all rights to the preset. 
Redistribution is prohibited.
Feel free to use this preset for commercial and personal use.


